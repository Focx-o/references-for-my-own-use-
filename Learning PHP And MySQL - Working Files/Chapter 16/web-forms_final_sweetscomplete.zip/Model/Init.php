<?php
define('DB_USER', 'project');
define('DB_PWD', 'password');
define('DB_NAME', 'project');
define('DB_HOST', 'localhost');
define('DB_DSN', 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME);
