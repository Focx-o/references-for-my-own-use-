<div class="content">
	<br/>
	<div class="product-list">
		
		<h2>Sign Up</h2>
		<br/>
		
		<b>Please use this form to contact us.</b><br/><br/>
		<form>
			<p>
				<label>Name: </label>
				<input type="text" name="name"/>
			<p>
			<p>
				<label>Email Address: </label>
				<input type="text" name="email"/>
			<p>
			<p>
				<label>Comments / Questions: </label>
				<textarea name="comments">I love your products!</textarea>
			<p>
			<p>
				<input type="reset" name="clear" value="Clear" class="button"/>
				<input type="submit" name="submit" value="Submit" class="button marL10"/>
			<p>
		</form>
	</div><!-- product-list -->

<br class="clear-all"/>
</div><!-- content -->

</div><!-- maincontent -->
